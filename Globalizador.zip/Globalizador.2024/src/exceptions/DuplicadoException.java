public class DuplicadoException extends Exception {
    public DuplicadoException(String mensaje) {
        super(mensaje);
    }
}
