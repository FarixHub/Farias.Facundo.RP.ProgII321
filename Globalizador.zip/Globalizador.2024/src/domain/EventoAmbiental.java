import java.io.Serializable;

public class EventoAmbiental implements Serializable {
    private String nombreEvento;
    private String fecha;
    private int capacidadMaxima;
    private String estado;

    public EventoAmbiental(String nombreEvento, String fecha, int capacidadMaxima, String estado) {
        this.nombreEvento = nombreEvento;
        this.fecha = fecha;
        this.capacidadMaxima = capacidadMaxima;
        this.estado = estado;
    }

    public String getNombreEvento() { return nombreEvento; }
    public String getFecha() { return fecha; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String toString() {
        return "Evento: " + nombreEvento + ", Fecha: " + fecha + ", Estado: " + estado;
    }
}
