import java.io.Serializable;
import java.util.List;

public abstract class AreaProtegida implements Serializable {  // Implementamos Serializable
    private String nombre;
    private double superficie;
    private String fechaEstablecimiento;

    public AreaProtegida(String nombre, double superficie, String fechaEstablecimiento) {
        this.nombre = nombre;
        this.superficie = superficie;
        this.fechaEstablecimiento = fechaEstablecimiento;
    }

    public String getNombre() {
        return nombre;
    }

    public double getSuperficie() {
        return superficie;
    }

    public String getFechaEstablecimiento() {
        return fechaEstablecimiento;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Superficie: " + superficie + " hectáreas, Fecha de Establecimiento: " + fechaEstablecimiento;
    }
}
