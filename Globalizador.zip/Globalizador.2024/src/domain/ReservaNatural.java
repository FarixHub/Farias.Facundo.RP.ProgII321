import java.io.Serializable;

public class ReservaNatural extends AreaProtegida implements Serializable {  // Implementamos Serializable
    private String nivelProteccion;

    public ReservaNatural(String nombre, double superficie, String fechaEstablecimiento, String nivelProteccion) {
        super(nombre, superficie, fechaEstablecimiento);
        this.nivelProteccion = nivelProteccion;
    }

    public String getNivelProteccion() {
        return nivelProteccion;
    }

    @Override
    public String toString() {
        return super.toString() + ", Nivel de Protección: " + nivelProteccion;
    }
}
