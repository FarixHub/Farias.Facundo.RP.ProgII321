import java.io.Serializable;
import java.util.List;

public class ParqueNacional extends AreaProtegida implements Serializable {  // Implementamos Serializable
    private List<String> actividadesTuristicas;

    public ParqueNacional(String nombre, double superficie, String fechaEstablecimiento, List<String> actividadesTuristicas) {
        super(nombre, superficie, fechaEstablecimiento);
        this.actividadesTuristicas = actividadesTuristicas;
    }

    public List<String> getActividadesTuristicas() {
        return actividadesTuristicas;
    }

    @Override
    public String toString() {
        return super.toString() + ", Actividades Turísticas: " + actividadesTuristicas;
    }
}
