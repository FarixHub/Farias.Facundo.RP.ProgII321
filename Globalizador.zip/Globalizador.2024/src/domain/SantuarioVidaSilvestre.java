import java.io.Serializable;
import java.util.List;

public class SantuarioVidaSilvestre extends AreaProtegida implements Serializable {  // Implementamos Serializable
    private List<String> especiesProtegidas;

    public SantuarioVidaSilvestre(String nombre, double superficie, String fechaEstablecimiento, List<String> especiesProtegidas) {
        super(nombre, superficie, fechaEstablecimiento);
        this.especiesProtegidas = especiesProtegidas;
    }

    public List<String> getEspeciesProtegidas() {
        return especiesProtegidas;
    }

    @Override
    public String toString() {
        return super.toString() + ", Especies Protegidas: " + especiesProtegidas;
    }
}
