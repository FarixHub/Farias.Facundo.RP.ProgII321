import java.util.Arrays;

public class SistemaParquesNacionales {
    public static void main(String[] args) {
        try {
            // Gestión de Áreas Protegidas
            GestionAreasProtegidas gestionAreas = new GestionAreasProtegidas();
            
            // Crear y agregar áreas protegidas
            ParqueNacional parque1 = new ParqueNacional("Monte Verde", 1500.5, "1990-05-10", 
                                                        Arrays.asList("Camping", "Senderismo"));
            ReservaNatural reserva1 = new ReservaNatural("Bosque Encantado", 800.0, "2005-11-20", 
                                                         "ALTO");
            SantuarioVidaSilvestre santuario1 = new SantuarioVidaSilvestre("Refugio de Aves", 300.0, 
                                                                           "2010-08-15", 
                                                                           Arrays.asList("Águila", "Colibrí"));

            gestionAreas.agregarArea(parque1);
            gestionAreas.agregarArea(reserva1);
            gestionAreas.agregarArea(santuario1);

            System.out.println("Áreas protegidas agregadas:");
            gestionAreas.mostrarAreas();

            // Probar duplicados
            try {
                gestionAreas.agregarArea(new ParqueNacional("Monte Verde", 1500.5, "1990-05-10", 
                                                            Arrays.asList("Camping")));
            } catch (DuplicadoException e) {
                System.out.println(e.getMessage());
            }

            // Filtro por tipo
            System.out.println("\nFiltrando solo parques nacionales:");
            gestionAreas.filtrarPorTipo(ParqueNacional.class).forEach(System.out::println);

            // Gestión de Eventos
            GestionEventos gestionEventos = new GestionEventos();
            
            // Crear y registrar eventos
            gestionEventos.registrarEvento(new EventoAmbiental("Limpieza Monte Verde", "2024-12-15", 
                                                                50, "PROGRAMADO"));
            gestionEventos.registrarEvento(new EventoAmbiental("Charlas Ambientales", "2024-11-30", 
                                                                100, "REALIZADO"));

            System.out.println("\nEventos registrados:");
            gestionEventos.mostrarEventos();

            // Cambiar estado de un evento
            System.out.println("\nActualizando estado del evento...");
            gestionEventos.cambiarEstado("Limpieza Monte Verde", "REALIZADO");

            System.out.println("\nEventos actualizados:");
            gestionEventos.mostrarEventos();

            // Ordenar áreas y eventos
            System.out.println("\nÁreas protegidas ordenadas por nombre:");
            gestionAreas.ordenarPorNombre();
            gestionAreas.mostrarAreas();

            System.out.println("\nEventos ordenados por fecha:");
            gestionEventos.ordenarPorFecha();
            gestionEventos.mostrarEventos();

            // Persistencia
            System.out.println("\nGuardando y cargando datos...");
            gestionAreas.guardarDatos("areas.csv");
            gestionEventos.guardarDatos("eventos.csv");

            GestionAreasProtegidas gestionCargada = new GestionAreasProtegidas();
            gestionCargada.cargarDatos("areas.csv");
            System.out.println("\nÁreas cargadas desde el archivo:");
            gestionCargada.mostrarAreas();

            GestionEventos eventosCargados = new GestionEventos();
            eventosCargados.cargarDatos("eventos.csv");
            System.out.println("\nEventos cargados desde el archivo:");
            eventosCargados.mostrarEventos();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
