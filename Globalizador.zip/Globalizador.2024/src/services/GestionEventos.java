import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class GestionEventos {
    private List<EventoAmbiental> eventos;

    public GestionEventos() {
        this.eventos = new ArrayList<>();
    }

    public void registrarEvento(EventoAmbiental evento) {
        eventos.add(evento);
    }

    public void cambiarEstado(String nombreEvento, String nuevoEstado) throws Exception {
        EventoAmbiental evento = eventos.stream()
                .filter(e -> e.getNombreEvento().equals(nombreEvento))
                .findFirst()
                .orElseThrow(() -> new Exception("Evento no encontrado: " + nombreEvento));
        evento.setEstado(nuevoEstado);
    }

    public void mostrarEventos() {
        eventos.forEach(System.out::println);
    }

    public void mostrarEventosPorEstado(String estado) {
        eventos.stream()
                .filter(e -> e.getEstado().equals(estado))
                .forEach(System.out::println);
    }

    public void ordenarPorFecha() {
        eventos.sort(Comparator.comparing(EventoAmbiental::getFecha));
    }

    // Persistencia
    public void guardarDatos(String archivo) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo))) {
            out.writeObject(eventos);
        }
    }

    public void cargarDatos(String archivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(archivo))) {
            eventos = (List<EventoAmbiental>) in.readObject();
        }
    }
}
