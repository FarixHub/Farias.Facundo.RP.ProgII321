import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class GestionAreasProtegidas {
    private List<AreaProtegida> areas;

    public GestionAreasProtegidas() {
        this.areas = new ArrayList<>();
    }

    public void agregarArea(AreaProtegida area) throws DuplicadoException {
        for (AreaProtegida a : areas) {
            if (a.getNombre().equals(area.getNombre()) &&
                a.getFechaEstablecimiento().equals(area.getFechaEstablecimiento())) {
                throw new DuplicadoException("Área duplicada: " + area.getNombre());
            }
        }
        areas.add(area);
    }

    public List<AreaProtegida> filtrarPorTipo(Class<?> tipo) {
        return areas.stream()
                .filter(tipo::isInstance)
                .collect(Collectors.toList());
    }

    public void mostrarAreas() {
        areas.forEach(System.out::println);
    }

    public void ordenarPorNombre() {
        areas.sort(Comparator.comparing(AreaProtegida::getNombre));
    }

    public void guardarDatos(String archivo) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(archivo))) {
            out.writeObject(areas);
        }
    }

    public void cargarDatos(String archivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(archivo))) {
            areas = (List<AreaProtegida>) in.readObject();
        }
    }
}
